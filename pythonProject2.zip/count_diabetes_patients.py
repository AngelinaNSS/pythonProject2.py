import pandas as pd

# Load the CSV file
df = pd.read_csv('diabetes_clean.csv')

# Count the number of diabetes patients (where Outcome is 1)
num_diabetes_patients = df[df['Outcome'] == 1].shape[0]

# Print the result
print(f'The number of diabetes patients in the dataset is: {num_diabetes_patients}')


