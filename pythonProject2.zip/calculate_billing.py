import pandas as pd

# Load the CSV file
df = pd.read_csv('diabetes_clean.csv')

# Check for missing values
print("Missing values in each column:")
print(df.isnull().sum())

# Optional: Drop or fill missing values
df = df.fillna(0)  # Fill missing values with 0

# Define billable amounts
billable_amounts = {
    'Pregnancies': 50.0,
    'Glucose': 75.0,
    'BloodPressure': 100.0,
    'Insulin': 80.0,
    'BMI': 90.0,
    'DiabetesPedigreeFunction': 70.0
}

# Initialize total billing amount
total_billing = 0

# Calculate total billing for each patient
for index, row in df.iterrows():
    total_billing += (row['Pregnancies'] * billable_amounts['Pregnancies'] +
                      row['Glucose'] * billable_amounts['Glucose'] +
                      row['BloodPressure'] * billable_amounts['BloodPressure'] +
                      row['Insulin'] * billable_amounts['Insulin'] +
                      row['BMI'] * billable_amounts['BMI'])

# Print the overall billing amount
print(f'The overall amount the hospital could bill is: {total_billing}')


