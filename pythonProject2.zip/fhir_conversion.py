import pandas as pd
from fhir.resources.bundle import Bundle  # Updated import for Bundle
from fhir.resources.patient import Patient  # Updated import for Patient
from fhir.resources.observation import Observation  # Updated import for Observation
from fhir.resources.codeableconcept import CodeableConcept  # Updated import for CodeableConcept
from fhir.resources.coding import Coding  # Updated import for Coding
from fhir.resources.quantity import Quantity  # Updated import for Quantity
from fhir.resources.identifier import Identifier  # Updated import for Identifier
from fhir.resources.reference import Reference  # Updated import for Reference

# Load the CSV file
data = pd.read_csv('/Users/angelinasubeksimon/Desktop/deggendorf/foundation of science downloads- spittler/pythonProject2/data.csv')  # Update this line

def convert_table_to_fhir_bundle(data):
    # Initialize a FHIR Bundle
    bundle = Bundle(type="collection")  # TODO-FHIR: Set the type for the Bundle

    # Process each row in the DataFrame
    for index, row in data.iterrows():
        # Create Patient and Observation resources
        patient = Patient(
            id=row['patient_id'],  # Ensure your CSV has a 'patient_id' column
            birthDate=row['birth_date']  # Ensure your CSV has a 'birth_date' column
        )

        observation = Observation(
            id=row['observation_id'],  # Ensure your CSV has an 'observation_id' column
            status='final',
            code=Coding(
                system="http://loinc.org",
                code=row['loinc_code'],  # Ensure your CSV has a 'loinc_code' column
                display=row['observation_display']  # Ensure your CSV has an 'observation_display' column
            ),
            subject=Reference(reference=f'Patient/{patient.id}'),
            valueQuantity=Quantity(value=row['value'], unit=row['unit']),  # Ensure your CSV has 'value' and 'unit' columns
        )

        # Add resources to the Bundle
        bundle.entry.append({'resource': patient})
        bundle.entry.append({'resource': observation})

    return bundle

# Create the FHIR Bundle
fhir_bundle = convert_table_to_fhir_bundle(data)

# Print the FHIR Bundle
print(fhir_bundle.json())








