import pandas as pd

# Load the dataset
df = pd.read_csv('/Users/angelinasubeksimon/Desktop/deggendorf/foundation of science downloads- spittler/pythonProject2/count_records.py')

# Print the number of records
num_records = df.shape[0]
print(f'The dataset contains {num_records} records.')

