import pandas as pd

# Load the CSV file into a DataFrame
df = pd.read_csv('diabetes_clean.csv')

# Print the column names to check for any issues
print(df.columns)

# Check if 'Outcome' is among the column names
if 'Outcome' in df.columns:
    # Count the number of diabetes patients (Outcome = 1)
    num_diabetes_patients = df[df['Outcome'] == 1].shape[0]
    print(f'The number of diabetes patients in the dataset is: {num_diabetes_patients}')
else:
    print("Column 'Outcome' not found in the DataFrame.")
