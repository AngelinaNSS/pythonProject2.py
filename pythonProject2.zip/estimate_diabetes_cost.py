import pandas as pd

# Load the CSV file
df = pd.read_csv('diabetes_clean.csv')

# Define average cost per diabetes patient
average_cost_per_patient = 10000  # in USD

# Calculate the number of diabetes patients
num_diabetes_patients = df[df['Outcome'] == 1].shape[0]

# Calculate total estimated cost
total_cost = num_diabetes_patients * average_cost_per_patient

# Print the total estimated cost
print(f'The estimated cost of treating {num_diabetes_patients} diabetes patients is: {total_cost} USD')
